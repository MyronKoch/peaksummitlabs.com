'use strict';
// Pure recipe parser. No DOM, no chrome APIs. Works in the popup (globalThis.RecipeParser) and in node.
(function () {
  const NAMED = {
    amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ensp: ' ', emsp: ' ', thinsp: ' ',
    ndash: '–', mdash: '\u2014', hellip: '…', lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”',
    sbquo: '‚', bdquo: '„', prime: '′', Prime: '″',
    frac12: '½', frac14: '¼', frac34: '¾', frac13: '⅓', frac23: '⅔',
    frac18: '⅛', frac38: '⅜', frac58: '⅝', frac78: '⅞',
    deg: '°', times: '×', middot: '·', bull: '•', copy: '©', reg: '®', trade: '™',
    plusmn: '±', minus: '−', rarr: '→', ordm: 'º', ordf: 'ª', shy: '',
    eacute: 'é', egrave: 'è', ecirc: 'ê', euml: 'ë', agrave: 'à', aacute: 'á',
    acirc: 'â', auml: 'ä', aring: 'å', ccedil: 'ç', iacute: 'í', igrave: 'ì',
    icirc: 'î', ntilde: 'ñ', oacute: 'ó', ograve: 'ò', ocirc: 'ô', ouml: 'ö',
    uacute: 'ú', ugrave: 'ù', ucirc: 'û', uuml: 'ü',
    Eacute: 'É', Agrave: 'À', Ccedil: 'Ç', Ntilde: 'Ñ', Ouml: 'Ö', Uuml: 'Ü'
  };

  function decodeEntities(s) {
    return String(s).replace(/&(#x[0-9a-f]+|#[0-9]+|[a-z][a-z0-9]*);/gi, function (m, e) {
      if (e[0] === '#') {
        const code = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
        if (!code || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return ' ';
        try { return String.fromCodePoint(code); } catch (_) { return m; }
      }
      if (Object.prototype.hasOwnProperty.call(NAMED, e)) return NAMED[e];
      const lower = e.toLowerCase();
      if (Object.prototype.hasOwnProperty.call(NAMED, lower)) return NAMED[lower];
      return m;
    });
  }

  function stripTags(s) {
    return s.replace(/<!--[\s\S]*?-->/g, '').replace(/<\/?[a-z][^>]*>/gi, '');
  }

  // HTML-ish string -> plain text, with line breaks kept as \n
  function htmlToText(input) {
    let s = String(input)
      .replace(/<\s*br\s*\/?>/gi, '\n')
      .replace(/<\/\s*(p|div|li|h[1-6]|tr|ul|ol)\s*>/gi, '\n')
      .replace(/<\s*li\b[^>]*>/gi, '\n');
    for (let i = 0; i < 3; i++) {
      s = decodeEntities(stripTags(s));
      if (!/<\/?[a-z][^>]*>/i.test(s)) break;
    }
    return s;
  }

  function collapse(s) {
    return s.replace(/[​-‍﻿]/g, '').replace(/\s+/g, ' ').trim();
  }
  function lines(s) {
    return htmlToText(s).split(/\n+/).map(collapse).filter(Boolean);
  }
  function clean(s) {
    if (s == null) return '';
    return lines(toStr(s)).join(' ');
  }
  function toStr(x) {
    if (x == null) return '';
    if (typeof x === 'string') return x;
    if (typeof x === 'number') return String(x);
    if (typeof x === 'object') return toStr(x.text || x.name || x['@value'] || '');
    return '';
  }
  function asArray(x) { return Array.isArray(x) ? x : x == null ? [] : [x]; }
  function flat(x, depth) {
    depth = depth || 0;
    if (!Array.isArray(x) || depth > 6) return [x];
    return x.reduce(function (a, v) { return a.concat(flat(v, depth + 1)); }, []);
  }

  // ---- durations ----
  function textMinutes(s) {
    let total = 0, found = false, m;
    if ((m = /(\d+(?:\.\d+)?)\s*(?:h|hr|hrs|hour|hours)\b/i.exec(s))) { total += parseFloat(m[1]) * 60; found = true; }
    if ((m = /(\d+(?:\.\d+)?)\s*(?:m|min|mins|minute|minutes)\b/i.exec(s))) { total += parseFloat(m[1]); found = true; }
    if (!found && /^\d+$/.test(s)) { total = parseInt(s, 10); found = true; }
    return found ? Math.round(total) : null;
  }
  // Returns whole minutes, or null when absent/zero/unparseable.
  function durationMinutes(v) {
    const first = flat(asArray(v))[0];
    if (first == null || typeof first === 'object') return null;
    const s = String(first).trim();
    if (!s) return null;
    const m = /^P(?:(\d+(?:[.,]\d+)?)Y)?(?:(\d+(?:[.,]\d+)?)M)?(?:(\d+(?:[.,]\d+)?)W)?(?:(\d+(?:[.,]\d+)?)D)?(?:T(?:(\d+(?:[.,]\d+)?)H)?(?:(\d+(?:[.,]\d+)?)M)?(?:(\d+(?:[.,]\d+)?)S)?)?$/i.exec(s);
    let total;
    if (m) {
      const n = function (x) { return x ? parseFloat(x.replace(',', '.')) : 0; };
      total = Math.round(n(m[1]) * 525600 + n(m[2]) * 43200 + n(m[3]) * 10080 + n(m[4]) * 1440 + n(m[5]) * 60 + n(m[6]) + n(m[7]) / 60);
    } else {
      total = textMinutes(clean(s));
    }
    return total && total > 0 ? total : null;
  }
  function formatMinutes(total) {
    if (!total || total <= 0) return '';
    const h = Math.floor(total / 60), mi = total % 60;
    const parts = [];
    if (h) parts.push(h + ' hr');
    if (mi) parts.push(mi + ' min');
    return parts.join(' ');
  }
  // ISO duration -> "1 hr 30 min". Unparseable non-empty text is passed through cleaned; zero -> ''.
  function parseDuration(v) {
    const mins = durationMinutes(v);
    if (mins) return formatMinutes(mins);
    const first = flat(asArray(v))[0];
    if (typeof first === 'string' && !/^P[TYMWDHS\d.,]*$/i.test(first.trim())) {
      const c = clean(first);
      if (c && !/^0+(\s*(min|minutes|hr|hours))?$/i.test(c)) return c;
    }
    return '';
  }

  // ---- field helpers ----
  function normUrl(u, base) {
    u = String(u || '').trim();
    if (!u) return '';
    try {
      const abs = new URL(u.startsWith('//') ? 'https:' + u : u, base || undefined);
      return /^https?:$/.test(abs.protocol) ? abs.href : '';
    } catch (_) { return ''; }
  }
  // Estimated pixel width from a URL: the largest number in NxM, fit=N%2CM / fit=N,M, w_N / w=N / width=N.
  function urlWidth(u) {
    const patterns = [/(\d{2,5})x(\d{2,5})/gi, /fit=(\d{2,5})(?:%2C|,)(\d{2,5})/gi, /(?:^|[^a-z])(?:w|width)[_=](\d{2,5})(?!\d)/gi];
    let best = 0;
    patterns.forEach(function (re) {
      let m;
      while ((m = re.exec(u))) {
        m.slice(1).forEach(function (d) { const n = parseInt(d, 10); if (n > best) best = n; });
      }
    });
    return best || null;
  }
  function declaredWidth(w) {
    if (typeof w === 'number') return isFinite(w) && w > 0 ? w : null;
    if (typeof w === 'string' && /^\s*\d+\s*$/.test(w)) { const n = parseInt(w, 10); return n > 0 ? n : null; }
    return null;
  }
  function imageCandidates(v, base, depth, out) {
    if (v == null || depth > 5) return out;
    if (typeof v === 'string') {
      const u = normUrl(decodeEntities(v), base);
      if (u) out.push({ url: u, width: urlWidth(u) });
      return out;
    }
    if (Array.isArray(v)) {
      v.forEach(function (item) { imageCandidates(item, base, depth + 1, out); });
      return out;
    }
    if (typeof v === 'object') {
      const raw = v.url || v.contentUrl || v.src || '';
      if (typeof raw === 'string') {
        const u = normUrl(decodeEntities(raw), base);
        if (u) out.push({ url: u, width: declaredWidth(v.width) || urlWidth(u) });
        return out;
      }
      return imageCandidates(raw, base, depth + 1, out);
    }
    return out;
  }
  // Largest known-width candidate; if no candidate has a known width, the first one.
  function firstImage(v, base) {
    const c = imageCandidates(v, base, 0, []);
    if (!c.length) return '';
    let best = null;
    c.forEach(function (x) { if (x.width && (!best || x.width > best.width)) best = x; });
    return best ? best.url : c[0].url;
  }
  function pickYield(v) {
    const c = flat(asArray(v)).map(clean).filter(Boolean);
    if (!c.length) return '';
    const withText = c.filter(function (x) { return /[a-z]/i.test(x); });
    if (!withText.length) return c[0];
    return withText.reduce(function (a, b) { return b.length > a.length ? b : a; });
  }
  function authorNames(v) {
    const out = [];
    flat(asArray(v)).forEach(function (a) {
      const n = clean(typeof a === 'string' ? a : a && a.name);
      if (n && out.indexOf(n) < 0) out.push(n);
    });
    return out.join(', ');
  }
  function ingredientsFrom(r) {
    const src = r.recipeIngredient != null ? r.recipeIngredient : r.ingredients != null ? r.ingredients : r.recipeIngredients;
    if (typeof src === 'string') return lines(src);
    return flat(asArray(src)).map(clean).filter(Boolean);
  }
  // recipeCategory: a string, an array of strings, or a comma-separated string. Returns "A, B" (deduped, first spelling kept).
  function categoryOf(v) {
    const out = [];
    const seen = {};
    flat(asArray(v)).forEach(function (item) {
      clean(toStr(item)).split(',').forEach(function (part) {
        const c = clean(part);
        const key = c.toLowerCase();
        if (c && !Object.prototype.hasOwnProperty.call(seen, key)) { seen[key] = true; out.push(c); }
      });
    });
    return out.join(', ');
  }

  // ---- instructions ----
  function stripNumber(s) { return s.replace(/^\s*(?:step\s*)?\d{1,2}\s*[.):]\s+(?=\S)/i, ''); }
  function stepLines(s) { return lines(s).map(stripNumber).map(collapse).filter(Boolean); }
  function typesOf(n) { return asArray(n && n['@type']).map(String); }

  function flattenSteps(x, depth) {
    depth = depth || 0;
    if (x == null || depth > 6) return [];
    if (typeof x === 'string') return stepLines(x);
    if (Array.isArray(x)) return x.reduce(function (a, v) { return a.concat(flattenSteps(v, depth + 1)); }, []);
    if (typeof x === 'object') {
      if (x.itemListElement) return flattenSteps(x.itemListElement, depth + 1);
      const t = stripNumber(clean(x.text || x.name || x.description || ''));
      return t ? [t] : [];
    }
    return [];
  }
  function parseInstructions(ins) {
    const sections = [];
    let loose = null;
    function addSteps(steps) {
      if (!steps.length) return;
      if (!loose) { loose = { name: '', steps: [] }; sections.push(loose); }
      loose.steps = loose.steps.concat(steps);
    }
    function walk(node, depth) {
      if (node == null || depth > 6) return;
      if (typeof node === 'string') { addSteps(stepLines(node)); return; }
      if (Array.isArray(node)) { node.forEach(function (n) { walk(n, depth + 1); }); return; }
      if (typeof node !== 'object') return;
      const isSection = typesOf(node).indexOf('HowToSection') >= 0 || (node.itemListElement && typesOf(node).indexOf('HowToStep') < 0);
      if (isSection) {
        const steps = flattenSteps(node.itemListElement);
        if (steps.length) { sections.push({ name: clean(node.name), steps: steps }); loose = null; }
        return;
      }
      const t = stripNumber(clean(node.text || node.name || node.description || ''));
      if (t) addSteps([t]);
    }
    walk(ins, 0);
    return sections;
  }

  // ---- JSON-LD ----
  function safeJson(text) {
    let t = String(text || '').replace(/^﻿/, '').trim();
    t = t.replace(/^<!\[CDATA\[/, '').replace(/\]\]>$/, '').trim();
    if (!t) return undefined;
    try { return JSON.parse(t); } catch (_) { /* try repair */ }
    const fixed = t
      .replace(/[\u0000-\u001f]/g, ' ')
      .replace(/,\s*([}\]])/g, '$1');
    try { return JSON.parse(fixed); } catch (_) { return undefined; }
  }
  function isRecipeNode(n) {
    return typesOf(n).some(function (t) { return /(^|[\/#:])Recipe$/i.test(t); });
  }
  function findRecipes(v, out, depth) {
    if (v == null || depth > 8 || typeof v !== 'object') return;
    if (Array.isArray(v)) { v.forEach(function (x) { findRecipes(x, out, depth + 1); }); return; }
    if (isRecipeNode(v)) { out.push(v); return; }
    Object.keys(v).forEach(function (k) {
      if (v[k] && typeof v[k] === 'object') findRecipes(v[k], out, depth + 1);
    });
  }

  function cleanPageTitle(t) {
    t = collapse(decodeEntities(String(t || '')));
    const parts = t.split(' - ');
    if (parts.length > 1 && /^gmail$/i.test(parts[parts.length - 1])) {
      parts.pop();
      if (parts.length > 1 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(parts[parts.length - 1])) parts.pop();
      const s = parts.join(' - ');
      return /^inbox(\s*\(\d+\))?$/i.test(s) ? '' : s;
    }
    return t;
  }

  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./i, ''); } catch (_) { return ''; }
  }

  function normalizeRecipe(r, p) {
    const sections = parseInstructions(r.recipeInstructions);
    const prep = durationMinutes(r.prepTime), cook = durationMinutes(r.cookTime), total = durationMinutes(r.totalTime);
    return {
      kind: 'recipe',
      name: clean(r.name) || clean(p.ogTitle) || cleanPageTitle(p.pageTitle) || 'Untitled recipe',
      image: firstImage(r.image, p.url) || firstImage(p.ogImage, p.url),
      description: clean(r.description),
      category: categoryOf(r.recipeCategory),
      author: authorNames(r.author),
      yield: pickYield(r.recipeYield),
      prepTime: parseDuration(r.prepTime),
      cookTime: parseDuration(r.cookTime),
      totalTime: parseDuration(r.totalTime),
      prepMinutes: prep,
      cookMinutes: cook,
      totalMinutes: total,
      ingredients: ingredientsFrom(r),
      sections: sections,
      notes: clean(r.recipeNotes || r.notes || ''),
      url: p.url
    };
  }
  function score(rec) {
    return rec.ingredients.length + rec.sections.reduce(function (n, s) { return n + s.steps.length; }, 0);
  }

  function parseRecipe(input) {
    const p = input || {};
    const url = typeof p.url === 'string' ? p.url : '';
    const sel = typeof p.selectionText === 'string' ? p.selectionText : '';
    const ctx = { url: url, ogTitle: p.ogTitle, ogImage: p.ogImage, pageTitle: p.pageTitle };

    if (sel.replace(/\s/g, '').length > 40) {
      const text = sel.replace(/\r\n?/g, '\n').replace(/[ \t ]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
      const firstLine = collapse(text.split('\n')[0] || '').slice(0, 60);
      const name = cleanPageTitle(p.pageTitle) || clean(p.ogTitle) || firstLine || 'Clipping';
      return { kind: 'clipping', name: name, text: text, url: url, category: '' };
    }

    let best = null;
    asArray(p.jsonLdTexts).forEach(function (txt) {
      const data = safeJson(txt);
      if (data == null) return;
      const found = [];
      findRecipes(data, found, 0);
      found.forEach(function (r) {
        const rec = normalizeRecipe(r, ctx);
        const s = score(rec);
        if (s > 0 && (!best || s > score(best))) best = rec;
      });
    });
    return best || { kind: 'none' };
  }

  // Display label for a yield: "Serves 4", "Makes 28", "Makes 2 loaves". Shared by popup and Doc.
  // Serves: bare number below 13, or a number followed by serving(s)/people. Otherwise Makes.
  function yieldLabel(y) {
    y = collapse(String(y == null ? '' : y));
    if (!y) return '';
    if (/^(serves|makes|yields?)\b/i.test(y)) return y;
    const NUM = '([\\d\\s\\-\\u2013to\\u00BD\\u00BC\\u00BE/.]+?)';
    const maxNum = function (s) {
      const n = (s.match(/\d+/g) || []).map(Number);
      return n.length ? Math.max.apply(null, n) : 0;
    };
    let m = new RegExp('^' + NUM + '\\s*(?:servings?|people|persons?|portions?)\\.?$', 'i').exec(y);
    if (m && /\d/.test(m[1])) return 'Serves ' + m[1].trim();
    m = new RegExp('^' + NUM + '$', 'i').exec(y);
    if (m && /\d/.test(m[1])) return (maxNum(m[1]) < 13 ? 'Serves ' : 'Makes ') + m[1].trim();
    return 'Makes ' + y;
  }

  const api = {
    parseRecipe: parseRecipe, parseDuration: parseDuration, durationMinutes: durationMinutes,
    formatMinutes: formatMinutes, decodeEntities: decodeEntities, cleanPageTitle: cleanPageTitle, hostOf: hostOf,
    yieldLabel: yieldLabel
  };
  globalThis.RecipeParser = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
