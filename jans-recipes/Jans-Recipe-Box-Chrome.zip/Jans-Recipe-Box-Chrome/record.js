'use strict';
// Builds the structured record (schema "recipebox/1") saved next to each Google Doc. See docs/SCHEMA.md.
(function () {
  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./i, ''); } catch (_) { return ''; }
  }
  function intOrNull(n) { return Number.isInteger(n) && n > 0 ? n : null; }

  // parsed: { kind 'video', name, image, url, author (channel), video: { id, channel, durationSeconds, description, recipeLinks, transcript } }
  function buildVideoRecord(parsed, meta) {
    const v = parsed.video || {};
    const t = v.transcript || {};
    return {
      schema: 'recipebox/1',
      id: meta.id,
      kind: 'video',
      name: meta.name || parsed.name || '',
      image: parsed.image || null,
      description: '',
      category: '',
      author: parsed.author || v.channel || '',
      yield: '',
      prepTime: '',
      cookTime: '',
      totalTime: '',
      prepMinutes: null,
      cookMinutes: null,
      totalMinutes: null,
      ingredients: [],
      sections: [],
      notes: '',
      text: '',
      url: parsed.url || '',
      sourceName: 'youtube.com',
      savedAt: meta.savedAt,
      docId: '',
      docLink: '',
      tags: ['From YouTube'],
      favorite: false,
      cookedCount: 0,
      video: {
        id: v.id || '',
        channel: v.channel || parsed.author || '',
        durationSeconds: Number.isInteger(v.durationSeconds) && v.durationSeconds > 0 ? v.durationSeconds : 0,
        description: v.description || '',
        recipeLinks: (v.recipeLinks || []).slice(),
        transcript: { lang: t.lang || '', kind: t.kind || '', text: t.text || '' },
        status: 'new'
      }
    };
  }

  // parsed: result of parseRecipe (kind recipe or clipping). meta: { id, savedAt, docId, docLink, name }
  function buildRecord(parsed, meta) {
    if (parsed.kind === 'video') return buildVideoRecord(parsed, meta);
    const isRecipe = parsed.kind === 'recipe';
    const url = parsed.url || '';
    return {
      schema: 'recipebox/1',
      id: meta.id,
      kind: isRecipe ? 'recipe' : 'clipping',
      name: meta.name || parsed.name || '',
      image: isRecipe && parsed.image ? parsed.image : null,
      description: isRecipe ? parsed.description || '' : '',
      category: isRecipe ? parsed.category || '' : '',
      author: isRecipe ? parsed.author || '' : '',
      yield: isRecipe ? parsed.yield || '' : '',
      prepTime: isRecipe ? parsed.prepTime || '' : '',
      cookTime: isRecipe ? parsed.cookTime || '' : '',
      totalTime: isRecipe ? parsed.totalTime || '' : '',
      prepMinutes: isRecipe ? intOrNull(parsed.prepMinutes) : null,
      cookMinutes: isRecipe ? intOrNull(parsed.cookMinutes) : null,
      totalMinutes: isRecipe ? intOrNull(parsed.totalMinutes) : null,
      ingredients: isRecipe ? (parsed.ingredients || []).slice() : [],
      sections: isRecipe ? (parsed.sections || []).map(function (s) { return { name: s.name || '', steps: (s.steps || []).slice() }; }) : [],
      notes: isRecipe ? parsed.notes || '' : '',
      text: isRecipe ? '' : parsed.text || '',
      url: url,
      sourceName: hostOf(url),
      savedAt: meta.savedAt,
      docId: meta.docId || '',
      docLink: meta.docLink || '',
      tags: [],
      favorite: false,
      cookedCount: 0
    };
  }

  function jsonFileName(name, id) {
    const base = String(name || 'Recipe').replace(/\s+/g, ' ').trim().slice(0, 100) || 'Recipe';
    return base + ' (' + String(id).slice(0, 8) + ').json';
  }

  const api = { buildRecord: buildRecord, jsonFileName: jsonFileName };
  globalThis.RecordBuilder = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
