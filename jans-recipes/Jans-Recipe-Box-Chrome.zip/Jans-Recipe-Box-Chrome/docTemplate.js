'use strict';
// Renders a parsed recipe/clipping into self-contained HTML that Google Drive converts into a Doc.
(function () {
  const RecipeParser = globalThis.RecipeParser || require('./parser.js');
  const FONT = 'font-family:Arial,Helvetica,sans-serif;';
  const BODY = FONT + 'font-size:14pt;line-height:1.7;color:#222222;';
  const P = 'style="' + BODY + 'margin:0 0 8pt 0;"';
  const LI = 'style="' + BODY + 'margin:0 0 6pt 0;"';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./i, ''); } catch (_) { return ''; }
  }
  function isHttp(url) { return /^https?:\/\//i.test(url || ''); }
  function today() {
    return new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  }
  function h(level, text, size) {
    return '<h' + level + ' style="' + FONT + 'font-size:' + size + 'pt;color:#222222;margin:16pt 0 6pt 0;">' + esc(text) + '</h' + level + '>';
  }
  function sourceLine(url) {
    if (!isHttp(url)) return '';
    return '<p ' + P + '>From: <a href="' + esc(url) + '">' + esc(hostOf(url) || url) + '</a></p>';
  }
  function footer(date) {
    return '<p style="' + FONT + 'font-size:10pt;color:#777777;margin-top:18pt;">Saved with Recipe Box on ' + esc(date) + '</p>';
  }
  function wrap(inner) {
    return '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="' + BODY + '">' + inner + '</body></html>';
  }

  function renderRecipe(r, opts) {
    opts = opts || {};
    const date = opts.date || today();
    const out = [];
    out.push('<h1 style="' + FONT + 'font-size:24pt;color:#222222;margin:0 0 10pt 0;">' + esc(r.name) + '</h1>');
    if (r.image && opts.includeImage !== false && isHttp(r.image)) {
      out.push('<p ' + P + '><img src="' + esc(r.image) + '" width="400" style="width:400px;" alt="' + esc(r.name) + '"></p>');
    }
    const bits = [];
    const y = RecipeParser.yieldLabel(r.yield);
    if (y) bits.push(y);
    if (r.prepTime) bits.push('Prep ' + r.prepTime);
    if (r.cookTime) bits.push('Cook ' + r.cookTime);
    if (r.totalTime) bits.push('Total ' + r.totalTime);
    if (bits.length) out.push('<p ' + P + '><b>' + esc(bits.join(' · ')) + '</b></p>');
    out.push(sourceLine(r.url));
    if (r.description) out.push('<p ' + P + '><i>' + esc(r.description) + '</i></p>');

    if (r.ingredients && r.ingredients.length) {
      out.push(h(2, 'Ingredients', 18));
      out.push('<ul style="list-style-type:none;padding-left:0;">' +
        r.ingredients.map(function (i) { return '<li ' + LI + '>☐ ' + esc(i) + '</li>'; }).join('') + '</ul>');
    }
    if (r.sections && r.sections.length) {
      out.push(h(2, 'Steps', 18));
      r.sections.forEach(function (s) {
        if (s.name) out.push(h(3, s.name, 15));
        out.push('<ol>' + s.steps.map(function (t) { return '<li ' + LI + '>' + esc(t) + '</li>'; }).join('') + '</ol>');
      });
    }
    if (r.notes) {
      out.push(h(2, 'Notes', 18));
      out.push('<p ' + P + '>' + esc(r.notes) + '</p>');
    }
    out.push(footer(date));
    return wrap(out.join(''));
  }

  function renderClipping(c, opts) {
    opts = opts || {};
    const date = opts.date || today();
    const paras = String(c.text || '').replace(/\r\n?/g, '\n').split(/\n\s*\n/)
      .map(function (p) { return p.trim(); }).filter(Boolean)
      .map(function (p) { return '<p ' + P + '>' + p.split('\n').map(esc).join('<br>') + '</p>'; });
    return wrap('<h1 style="' + FONT + 'font-size:24pt;color:#222222;margin:0 0 10pt 0;">' + esc(c.name) + '</h1>' +
      sourceLine(c.url) + paras.join('') + footer(date));
  }

  function docName(name) {
    return String(name || '').replace(/\s+/g, ' ').trim().slice(0, 100).trim() || 'Recipe';
  }

  const api = { renderRecipe: renderRecipe, renderClipping: renderClipping, docName: docName, esc: esc };
  globalThis.DocTemplate = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
