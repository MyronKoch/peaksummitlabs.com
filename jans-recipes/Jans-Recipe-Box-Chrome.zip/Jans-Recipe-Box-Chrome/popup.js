'use strict';
try { document.getElementById('ver').textContent = 'v' + chrome.runtime.getManifest().version; } catch (_) {}
// Runs only while the popup is open. Reads the page, shows a preview, saves on one button click.
// The pure helpers at the top (buildOpenUrl, performSave) are exported for tests; the page code runs only in the popup.
(function () {
  // Link that Chrome hands to the Mac app ("Jan's Recipes") to open one saved recipe.
  // Without an id the app just comes forward and refreshes.
  function buildOpenUrl(id) {
    return id ? 'jansrecipes://open?id=' + encodeURIComponent(String(id)) : 'jansrecipes://open';
  }

  // Saves one recipe. deps: { Drive, DocTemplate, RecordBuilder, newId(), nowIso(), findDuplicate(rbKey) (optional) }.
  // opts: { makeDoc (bool), date (string for the Doc header), rbKey (duplicate key, optional) }.
  // With makeDoc false only the JSON record is uploaded and docId/docLink stay empty.
  // When deps.findDuplicate finds a record with the same rbKey nothing is created and { duplicate: { fileId, recipeId }, openUrl } comes back.
  async function performSave(deps, parsed, opts) {
    const Drive = deps.Drive;
    if (opts.rbKey && deps.findDuplicate) {
      const dup = await deps.findDuplicate(opts.rbKey);
      if (dup) return { duplicate: dup, openUrl: buildOpenUrl(dup.recipeId) };
    }
    const folders = await Drive.ensureFolders();
    const docName = deps.DocTemplate.docName(parsed.name);
    let file = { id: '', webViewLink: '' };
    // A video is only ever saved as the JSON record; the app makes the recipe from it.
    const makeDoc = opts.makeDoc && parsed.kind !== 'video';

    if (makeDoc) {
      const render = function (includeImage) {
        return parsed.kind === 'recipe'
          ? deps.DocTemplate.renderRecipe(parsed, { date: opts.date, includeImage: includeImage })
          : deps.DocTemplate.renderClipping(parsed, { date: opts.date });
      };
      try {
        file = await Drive.saveDoc(render(true), docName, folders.folderId);
      } catch (e) {
        // A photo Google can't fetch may reject the whole upload; try again without it.
        if (e.status === 400 && parsed.kind === 'recipe' && parsed.image) {
          file = await Drive.saveDoc(render(false), docName, folders.folderId);
        } else { throw e; }
      }
    }

    // Structured copy for the Mac app, created after the Doc (if any) so it can point at it.
    const id = deps.newId();
    const savedAt = deps.nowIso();
    const record = deps.RecordBuilder.buildRecord(parsed, {
      id: id, name: docName, savedAt: savedAt, docId: file.id, docLink: file.webViewLink
    });
    let jsonId = '';
    for (let attempt = 0; attempt < 2 && !jsonId; attempt++) {
      try {
        const j = await Drive.saveJson(JSON.stringify(record, null, 2), deps.RecordBuilder.jsonFileName(docName, id), folders.dataFolderId,
          opts.rbKey ? { rbKey: opts.rbKey, rbId: id } : undefined);
        jsonId = j.id;
      } catch (e) { console.error(e); }
    }
    // Without a Doc the JSON record is the whole save, so its failure is a failed save.
    if (!jsonId && !makeDoc) throw new Error('The recipe record did not upload');

    return {
      id: id,
      openUrl: buildOpenUrl(id),
      savedAt: savedAt,
      docId: file.id,
      docLink: file.webViewLink,
      jsonId: jsonId,
      dataOk: !!jsonId,
      folderId: folders.folderId,
      folderLink: Drive.folderLink(folders.folderId)
    };
  }

  // Key a saved recipe is remembered under: the video id for YouTube, else the page address.
  function savedKeyFor(kind, url, videoId) {
    return kind === 'video' ? 'youtube:' + videoId : url;
  }

  // Entry for key in the stored "saved" map, or null. Tolerates a missing or odd map.
  function savedEntry(saved, key) {
    return (saved && typeof saved === 'object' && saved[key]) || null;
  }

  // True when the popup is allowed to read the tab (web pages and local files only).
  function isReadableUrl(url) {
    return /^https?:|^file:/i.test(String(url || ''));
  }

  // The Google Doc copy is ON unless the stored value is an explicit false.
  function resolveMakeDoc(stored) { return stored !== false; }

  const api = { resolveMakeDoc: resolveMakeDoc, buildOpenUrl: buildOpenUrl, performSave: performSave, savedKeyFor: savedKeyFor, savedEntry: savedEntry, isReadableUrl: isReadableUrl };
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
    return;
  }
  if (typeof document === 'undefined') return;

  const T0 = performance.now();
  const lap = function (label) { console.log('[recipebox timing] ' + label + ': ' + Math.round(performance.now() - T0) + ' ms'); };
  lap('popup script start');
  const $ = function (id) { return document.getElementById(id); };
  const STATES = ['s-loading', 's-preview', 's-dup', 's-none', 's-saving', 's-saved', 's-error'];
  let current = null;   // parsed result being previewed
  let retryFn = null;
  let openUrl = '';     // jansrecipes:// link for the record just saved
  let dupKey = '';      // the rbKey that dupP answers
  let dupP = null;      // quiet duplicate check started when the preview shows: resolves to a match, null (none) or undefined (could not tell)
  const DUP_BUDGET_MS = 25000;

  function show(id) {
    STATES.forEach(function (s) { $(s).hidden = s !== id; });
    $('actions').hidden = id !== 's-preview';
    document.body.classList.toggle('tall', id === 's-preview');
  }

  function showError(message, retry, err) {
    $('errMsg').textContent = message;
    $('errDetail').textContent = err ? 'Details: ' + String((err && (err.message || err.reason)) || err).slice(0, 200) : '';
    retryFn = retry;
    show('s-error');
  }

  function friendly(e) {
    const msg = String((e && e.message) || e || '');
    const status = e && e.status;
    const reason = String((e && e.reason) || '');
    if (/REPLACE_WITH_CLIENT_ID/.test(msg)) return "Recipe Box isn't fully set up yet. Please ask Myron to finish the setup.";
    if (status === 403 && /accessNotConfigured|has not been used|disabled/i.test(reason + ' ' + msg)) {
      return "Recipe Box isn't fully set up on Google's side yet. Please ask Myron to finish the setup.";
    }
    if (/did not approve|denied|cancel|closed|not granted|user_cancelled/i.test(msg)) {
      return "Recipe Box needs your permission to save into your Google Drive. Click \"Try again\", then choose Allow.";
    }
    if (/sign.?in|signed in|not signed|NO_TOKEN|OAuth2/i.test(msg) || status === 401) {
      return "I couldn't sign in to Google. Please make sure you are signed in to Chrome with your Google account, then click \"Try again\".";
    }
    if (/failed to fetch|network|load failed/i.test(msg)) {
      return "I couldn't reach Google. Please check your internet connection, then click \"Try again\".";
    }
    return "Something went wrong while saving. Please click \"Try again\". If it keeps happening, tell Myron.";
  }

  function clearEl(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  // Opens the Mac app. Chrome asks the first time; the tab Chrome opens is handed to the app.
  function openInApp(url) {
    try {
      chrome.tabs.create({ url: url, active: true }).catch(function (e) { console.error(e); });
    } catch (e) { console.error(e); }
  }

  function savedKey(res) {
    return savedKeyFor(res.kind, res.url, res.video && res.video.id);
  }

  function renderPreview(res) {
    current = res;
    const isVideo = res.kind === 'video';
    $('title').value = res.name;
    $('recipeBody').hidden = res.kind !== 'recipe';
    $('clipBody').hidden = res.kind !== 'clipping';
    $('videoBody').hidden = !isVideo;
    $('title').hidden = isVideo;
    $('titleLabel').hidden = isVideo;
    $('saveBtn').textContent = isVideo ? 'Save This Video Recipe' : 'Save to my Recipe Box';

    if (isVideo) {
      const th = $('vthumb');
      if (res.image) {
        th.onerror = function () { th.hidden = true; };
        th.src = res.image;
        th.hidden = false;
      } else { th.hidden = true; }
      $('vtitle').textContent = res.name;
      $('vchannel').textContent = res.author;
      $('vfound').textContent = RecipeYouTube.findingFor(res.video).message;
    } else if (res.kind === 'recipe') {
      const photo = $('photo');
      if (res.image) {
        photo.onerror = function () { photo.hidden = true; };
        photo.src = res.image;
        photo.hidden = false;
      } else {
        photo.hidden = true;
      }
      const bits = [];
      if (res.yield) bits.push(RecipeParser.yieldLabel(res.yield));
      if (res.prepTime) bits.push('Prep ' + res.prepTime);
      if (res.cookTime) bits.push('Cook ' + res.cookTime);
      if (res.totalTime) bits.push('Total ' + res.totalTime);
      $('meta').textContent = bits.join(' · ');
      $('meta').hidden = !bits.length;

      const ul = $('ingredients'); clearEl(ul);
      res.ingredients.forEach(function (t) {
        const li = document.createElement('li'); li.textContent = t; ul.appendChild(li);
      });
      const box = $('steps'); clearEl(box);
      res.sections.forEach(function (s) {
        if (s.name) {
          const h = document.createElement('div'); h.className = 'stepname'; h.textContent = s.name; box.appendChild(h);
        }
        const ol = document.createElement('ol');
        s.steps.forEach(function (t) {
          const li = document.createElement('li'); li.textContent = t; ol.appendChild(li);
        });
        box.appendChild(ol);
      });
    } else {
      $('clipText').textContent = res.text;
    }

    const host = RecipeParser.hostOf(res.url);
    $('source').textContent = host && !isVideo ? 'From: ' + host : '';
    show('s-preview');
  }

  const UNREADABLE = { friendly: "Chrome doesn't let Recipe Box read this kind of page. Please open a recipe web page and click Recipe Box again." };

  // Starts the storage read at once; it runs while the page is being read.
  function readStorage() {
    return chrome.storage.local.get(['saved', 'makeDoc']).catch(function () { return {}; });
  }

  // Runs a tiny function inside the tab: only raw page facts, no parsing there.
  async function readPage(tab) {
    let results;
    try {
      results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'ISOLATED',
        injectImmediately: true,
        func: function () {
          const meta = function (sel) { const m = document.querySelector(sel); return m ? m.content || '' : ''; };
          return {
            jsonLdTexts: Array.from(document.querySelectorAll('script[type="application/ld+json"]')).map(function (s) { return s.textContent; }),
            url: location.href,
            ogTitle: meta('meta[property="og:title"]'),
            ogImage: meta('meta[property="og:image"]'),
            selectionText: String(getSelection()),
            pageTitle: document.title
          };
        }
      });
    } catch (e) {
      throw Object.assign(new Error('inject failed: ' + (e && e.message)), { friendly: "I couldn't read this page. Try reloading the page, then click Recipe Box again." });
    }
    const data = results && results[0] && results[0].result;
    if (!data) throw Object.assign(new Error('no result'), { friendly: "I couldn't read this page. Try reloading the page, then click Recipe Box again." });
    return data;
  }

  // On a YouTube video page: run the extractor inside the tab. Returns a parsed 'video' result.
  async function readVideo(tab) {
    let results;
    try {
      results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: RecipeYouTube.recipeBoxExtractYouTube });
    } catch (e) {
      throw Object.assign(new Error('inject failed: ' + (e && e.message)), { friendly: "I couldn't read this video page. Try reloading the page, then click Recipe Box again." });
    }
    const d = results && results[0] && results[0].result;
    if (!d || d.error || !d.videoId || !d.title) {
      throw Object.assign(new Error('video read failed: ' + (d && d.error)), { friendly: "I couldn't read this video. Try reloading the page, then click Recipe Box again." });
    }
    const t = d.transcript || {};
    return {
      kind: 'video',
      name: d.title,
      image: d.thumbnail || null,
      url: d.url,
      author: d.channel,
      video: {
        id: d.videoId,
        channel: d.channel,
        durationSeconds: d.durationSeconds,
        description: d.description,
        recipeLinks: RecipeYouTube.extractRecipeLinks(d.description),
        transcript: { lang: t.lang || '', kind: t.kind || '', text: t.text || '' }
      }
    };
  }

  async function init() {
    show('s-loading');
    try {
      // Tab lookup and storage read start together; the page read follows the tab.
      const storageP = readStorage();
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      lap('tabs.query done');
      const tab = tabs && tabs[0];
      if (!tab || !tab.id || !isReadableUrl(tab.url)) throw Object.assign(new Error('unreadable'), UNREADABLE);

      const isVideoPage = !!RecipeYouTube.videoIdFrom(tab.url || '');
      let res;
      if (isVideoPage) {
        res = await readVideo(tab);
        lap('YouTube executeScript round trip done');
      } else {
        const data = await readPage(tab);
        lap('readPage executeScript round trip done');
        res = RecipeParser.parseRecipe(data);
        lap('parse done');
      }
      const store = await storageP;
      lap('storage read done');
      $('makeDoc').checked = resolveMakeDoc(store.makeDoc);
      if (res.kind === 'none') { show('s-none'); return; }
      renderPreview(res);
      startDupCheck(res);
      lap('render done');
    } catch (e) {
      console.error(e);
      showError(e.friendly || friendly(e), init);
    }
  }

  // Key for this page, or null when there is nothing to compare.
  function rbKeyFor(res) {
    return Dedupe.rbKeyOfRecord({ url: res.url, name: res.name, ingredients: res.ingredients || [] });
  }

  function showDuplicate(dup) {
    openUrl = buildOpenUrl(dup && dup.recipeId);
    show('s-dup');
  }

  // Runs after the preview is on screen; never blocks it. A match swaps the Save button for "Already in your Recipe Box".
  function startDupCheck(res) {
    dupP = null; dupKey = '';
    rbKeyFor(res).then(function (rbKey) {
      if (current !== res) return;
      if (!rbKey) return;
      dupKey = rbKey;
      const p = Drive.findDuplicate(rbKey, { interactive: false, keyOfRecord: Dedupe.rbKeyOfRecord })
        .catch(function (e) { console.log('[recipebox] duplicate check skipped:', e && e.message); return undefined; });
      dupP = p;
      p.then(function (dup) {
        lap('duplicate check done');
        if (dup && current === res && !$('s-preview').hidden) showDuplicate(dup);
      });
    }).catch(function (e) { console.error(e); });
  }

  // Used by save(): waits for the quiet check; if it could not tell, asks again now (signed in) before anything is created.
  async function dupCheckForSave(rbKey) {
    let dup = dupP && dupKey === rbKey ? await dupP : undefined;
    if (dup === undefined) {
      dup = await Promise.race([
        Drive.findDuplicate(rbKey, { interactive: true, keyOfRecord: Dedupe.rbKeyOfRecord }),
        new Promise(function (_, rej) { setTimeout(function () { rej(new Error('network: duplicate check timed out')); }, DUP_BUDGET_MS); })
      ]);
    }
    return dup;
  }

  async function storeMakeDoc() {
    try {
      await chrome.storage.local.set({ makeDoc: $('makeDoc').checked });
    } catch (e) { console.error(e); }
  }

  async function rememberSaved(url, entry) {
    try {
      const o = await chrome.storage.local.get('saved');
      const saved = o.saved || {};
      saved[url] = entry;
      await chrome.storage.local.set({ saved: saved });
    } catch (e) { console.error(e); }
  }

  async function save() {
    if (!current) return;
    show('s-saving');
    try {
      if (/REPLACE_WITH_CLIENT_ID/.test(chrome.runtime.getManifest().oauth2.client_id)) throw new Error('REPLACE_WITH_CLIENT_ID');
      // Sign in first: on the very first save Chrome shows a Google permission window,
      // which can close this popup. If that happens, she just clicks the button again.
      await Drive.getToken(true);

      const name = current.kind === 'video' ? current.name : ($('title').value.trim() || current.name);
      const parsed = Object.assign({}, current, { name: name });
      const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
      const rbKey = await rbKeyFor(parsed);
      const r = await performSave({
        Drive: Drive, DocTemplate: DocTemplate, RecordBuilder: RecordBuilder,
        newId: function () { return crypto.randomUUID(); },
        nowIso: function () { return new Date().toISOString(); },
        findDuplicate: dupCheckForSave
      }, parsed, { makeDoc: $('makeDoc').checked, date: date, rbKey: rbKey });
      if (r.duplicate) { showDuplicate(r.duplicate); return; }

      await rememberSaved(savedKey(parsed), { id: r.id, docId: r.docId, jsonId: r.jsonId, link: r.docLink, savedAt: r.savedAt });

      const isVideo = parsed.kind === 'video';
      $('savedHead').textContent = isVideo ? "Saved! Jan's Recipes will turn it into a recipe for you to check." : 'Saved to your Recipe Box!';
      openUrl = r.openUrl;
      $('openAppBtn').hidden = !r.dataOk;
      $('docLink').href = r.docLink;
      $('docLink').hidden = !r.docLink;
      $('folderLink').href = r.folderLink;
      const note = $('savedNote');
      note.hidden = r.dataOk;
      if (!r.dataOk) note.textContent = 'Your recipe is saved. The copy for the cookbook app did not finish, so it may not show up there.';
      show('s-saved');
    } catch (e) {
      console.error(e);
      showError(friendly(e), save, e);
    }
  }

  $('saveBtn').addEventListener('click', save);
  $('retryBtn').addEventListener('click', function () { if (retryFn) retryFn(); });
  $('openAppBtn').addEventListener('click', function () { if (openUrl) openInApp(openUrl); });
  $('openDupBtn').addEventListener('click', function () { if (openUrl) openInApp(openUrl); });
  $('makeDoc').addEventListener('change', storeMakeDoc);
  $('settingsLink').addEventListener('click', function () {
    const open = $('settingsPanel').hidden;
    $('settingsPanel').hidden = !open;
    $('settingsLink').setAttribute('aria-expanded', String(open));
  });
  // Let the static shell paint first, then start the async work.
  requestAnimationFrame(function () { setTimeout(init, 0); });
})();
