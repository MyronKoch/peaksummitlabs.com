'use strict';
// Google Drive helpers for the popup. Uses chrome.identity for sign-in; nothing runs in the background.
(function () {
  const API = 'https://www.googleapis.com/drive/v3';
  const UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink';
  const TOP_NAME = 'Recipe Box';
  const DATA_NAME = 'Recipe data';
  const FOLDER_MIME = 'application/vnd.google-apps.folder';

  class DriveError extends Error {
    constructor(message, status, reason) {
      super(message);
      this.name = 'DriveError';
      this.status = status || 0;
      this.reason = reason || '';
    }
  }

  async function getToken(interactive) {
    const r = await chrome.identity.getAuthToken({ interactive: !!interactive });
    const t = typeof r === 'string' ? r : r && r.token;
    if (!t) throw new DriveError('No sign-in', 0, 'NO_TOKEN');
    return t;
  }

  function send(url, init, token) {
    const headers = Object.assign({}, init && init.headers, { Authorization: 'Bearer ' + token });
    return fetch(url, Object.assign({}, init, { headers: headers }));
  }

  // On 401: drop the cached token and retry once. interactive defaults to true; the quiet
  // duplicate check passes false so it never opens a Google sign-in window by itself.
  async function authedFetch(url, init, interactive) {
    const inter = interactive !== false;
    let token = await getToken(inter);
    let res = await send(url, init, token);
    if (res.status === 401) {
      try { await chrome.identity.removeCachedAuthToken({ token: token }); } catch (_) { /* ignore */ }
      token = await getToken(inter);
      res = await send(url, init, token);
    }
    return res;
  }

  async function ok(res) {
    if (res.ok) return res.json();
    let msg = 'HTTP ' + res.status, reason = '';
    try {
      const j = await res.json();
      if (j && j.error) {
        msg = j.error.message || msg;
        reason = (j.error.errors && j.error.errors[0] && j.error.errors[0].reason) || j.error.status || '';
      }
    } catch (_) { /* not json */ }
    throw new DriveError(msg, res.status, reason);
  }

  async function storeGet(key) {
    const o = await chrome.storage.local.get(key);
    return o ? o[key] : undefined;
  }
  async function storeSet(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  // Find or create a folder (optionally inside parentId). Cached id is confirmed to exist and not be trashed.
  async function ensureFolder(name, parentId, cacheKey) {
    const cached = await storeGet(cacheKey);
    if (cached) {
      const res = await authedFetch(API + '/files/' + encodeURIComponent(cached) + '?fields=id,trashed');
      if (res.ok) {
        const f = await res.json();
        if (f && f.id && !f.trashed) return f.id;
      } else if (res.status !== 404) {
        await ok(res); // throws
      }
    }
    let q = "name='" + name + "' and mimeType='" + FOLDER_MIME + "' and trashed=false";
    if (parentId) q += " and '" + parentId + "' in parents";
    const found = await ok(await authedFetch(API + '/files?q=' + encodeURIComponent(q) +
      '&fields=files(id,name)&orderBy=createdTime&pageSize=5&spaces=drive'));
    let id = found.files && found.files[0] && found.files[0].id;
    if (!id) {
      const body = { name: name, mimeType: FOLDER_MIME };
      if (parentId) body.parents = [parentId];
      const created = await ok(await authedFetch(API + '/files?fields=id', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(body)
      }));
      id = created.id;
    }
    await storeSet(cacheKey, id);
    return id;
  }

  // "Recipe Box" and "Recipe Box/Recipe data". The data folder is looked up inside the top folder.
  async function ensureFolders() {
    const folderId = await ensureFolder(TOP_NAME, null, 'folderId');
    const cachedParent = await storeGet('dataFolderParent');
    if (cachedParent && cachedParent !== folderId) await storeSet('dataFolderId', '');
    const dataFolderId = await ensureFolder(DATA_NAME, folderId, 'dataFolderId');
    await storeSet('dataFolderParent', folderId);
    return { folderId: folderId, dataFolderId: dataFolderId };
  }

  async function multipartUpload(metadata, content, contentType) {
    const b = 'recipebox' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    const body =
      '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify(metadata) + '\r\n' +
      '--' + b + '\r\nContent-Type: ' + contentType + '\r\n\r\n' + content + '\r\n' +
      '--' + b + '--';
    return ok(await authedFetch(UPLOAD, {
      method: 'POST',
      headers: { 'Content-Type': 'multipart/related; boundary=' + b },
      body: body
    }));
  }

  // HTML -> Google Doc. Returns { id, webViewLink }.
  async function saveDoc(html, name, folderId) {
    const f = await multipartUpload(
      { name: name, mimeType: 'application/vnd.google-apps.document', parents: [folderId] },
      html, 'text/html; charset=UTF-8');
    if (!f.webViewLink) f.webViewLink = 'https://docs.google.com/document/d/' + f.id + '/edit';
    return f;
  }

  // Structured copy for the Mac app. Returns { id }.
  // props (optional): { rbKey, rbId } stored as Drive appProperties so a later save can find this file by key
  // without downloading it. Each value is far below Drive's 124-byte key+value limit (64-char hash, 36-char id).
  async function saveJson(jsonText, fileName, dataFolderId, props) {
    const meta = { name: fileName, mimeType: 'application/json', parents: [dataFolderId] };
    const ap = {};
    if (props && props.rbKey) ap.rbKey = String(props.rbKey);
    if (props && props.rbId) ap.rbId = String(props.rbId);
    if (Object.keys(ap).length) meta.appProperties = ap;
    return multipartUpload(meta, jsonText, 'application/json; charset=UTF-8');
  }

  // ---- Duplicate check (read-only: never creates a folder or a file) ----

  const LEGACY_CAP = 60;      // most recent files without rbKey read per check
  const LEGACY_PAGES = 5;     // 5 x 200 files listed at most
  const LEGACY_PARALLEL = 6;

  async function findFolder(name, parentId, interactive) {
    let q = "name='" + name + "' and mimeType='" + FOLDER_MIME + "' and trashed=false";
    if (parentId) q += " and '" + parentId + "' in parents";
    const found = await ok(await authedFetch(API + '/files?q=' + encodeURIComponent(q) +
      '&fields=files(id,name)&orderBy=createdTime&pageSize=5&spaces=drive', undefined, interactive));
    return (found.files && found.files[0] && found.files[0].id) || null;
  }

  // The "Recipe data" folder id, or null when it does not exist yet (then nothing can be a duplicate).
  async function lookupDataFolder(interactive) {
    const cached = await storeGet('dataFolderId');
    if (cached) {
      const res = await authedFetch(API + '/files/' + encodeURIComponent(cached) + '?fields=id,trashed', undefined, interactive);
      if (res.ok) {
        const f = await res.json();
        if (f && f.id && !f.trashed) return f.id;
      } else if (res.status !== 404) {
        await ok(res); // throws
      }
    }
    const top = await findFolder(TOP_NAME, null, interactive);
    if (!top) return null;
    return findFolder(DATA_NAME, top, interactive);
  }

  async function queryByRbKey(rbKey, folderId, interactive) {
    const q = "appProperties has { key='rbKey' and value='" + String(rbKey).replace(/[^0-9a-f]/gi, '') + "' }" +
      " and trashed=false and '" + folderId + "' in parents";
    const r = await ok(await authedFetch(API + '/files?q=' + encodeURIComponent(q) +
      '&fields=files(id,name,appProperties)&orderBy=createdTime&pageSize=5&spaces=drive', undefined, interactive));
    return (r.files && r.files[0]) || null;
  }

  // JSON files in the data folder that carry no rbKey (saved by extension 1.0.4 or earlier, or by an older app build). Newest first.
  async function listUnkeyed(folderId, interactive) {
    const out = [];
    let pageToken = '';
    for (let page = 0; page < LEGACY_PAGES; page++) {
      const q = "'" + folderId + "' in parents and trashed=false and mimeType!='" + FOLDER_MIME + "'";
      const r = await ok(await authedFetch(API + '/files?q=' + encodeURIComponent(q) +
        '&fields=nextPageToken,files(id,name,mimeType,appProperties)&orderBy=createdTime%20desc&pageSize=200&spaces=drive' +
        (pageToken ? '&pageToken=' + encodeURIComponent(pageToken) : ''), undefined, interactive));
      (r.files || []).forEach(function (f) {
        const isJson = /\.json$/i.test(f.name || '') || f.mimeType === 'application/json';
        if (isJson && !(f.appProperties && f.appProperties.rbKey)) out.push(f);
      });
      pageToken = r.nextPageToken || '';
      if (!pageToken) break;
    }
    return out;
  }

  async function downloadText(fileId, interactive) {
    const res = await authedFetch(API + '/files/' + encodeURIComponent(fileId) + '?alt=media', undefined, interactive);
    if (!res.ok) await ok(res); // throws
    return res.text ? res.text() : JSON.stringify(await res.json());
  }

  // Records saved before rbKey existed: read their source address once, remember the answer per file id.
  async function findLegacyDuplicate(rbKey, folderId, opts) {
    const inter = !!opts.interactive;
    const files = await listUnkeyed(folderId, inter);
    if (!files.length) return null;
    const stored = (await storeGet('legacyKeys')) || {};
    const live = {};
    files.forEach(function (f) { live[f.id] = true; });
    const cache = {};
    Object.keys(stored).forEach(function (id) { if (live[id]) cache[id] = stored[id]; });   // drops files that are gone

    const hit = function () {
      for (let i = 0; i < files.length; i++) {
        const c = cache[files[i].id];
        if (c && c.k === rbKey) return { fileId: files[i].id, recipeId: c.id || '' };
      }
      return null;
    };
    let found = hit();
    const todo = files.filter(function (f) { return !cache[f.id]; }).slice(0, LEGACY_CAP);
    for (let i = 0; i < todo.length && !found; i += LEGACY_PARALLEL) {
      await Promise.all(todo.slice(i, i + LEGACY_PARALLEL).map(async function (f) {
        try {
          const rec = JSON.parse(await downloadText(f.id, inter));
          const k = (rec && typeof rec === 'object') ? await opts.keyOfRecord(rec) : null;
          cache[f.id] = { k: k || '', id: rec && rec.id ? String(rec.id) : '' };
        } catch (e) {
          if (e instanceof SyntaxError || (e && e.status === 404)) cache[f.id] = { k: '', id: '' };   // unreadable for good
          /* anything else (network, 5xx) is left uncached and tried again next time */
        }
      }));
      found = hit();
    }
    try { await storeSet('legacyKeys', cache); } catch (_) { /* cache only */ }
    return found;
  }

  // Is there already a record with this rbKey in the user's data folder?
  // Returns { fileId, recipeId } or null. Throws on network / permission problems (the caller decides what that means).
  // opts: { interactive (default false), keyOfRecord(rec) -> Promise<rbKey|null> (enables the older-records fallback) }
  async function findDuplicate(rbKey, opts) {
    const o = opts || {};
    const inter = !!o.interactive;
    if (!rbKey) return null;
    const folderId = await lookupDataFolder(inter);
    if (!folderId) return null;
    const hit = await queryByRbKey(rbKey, folderId, inter);
    if (hit) return { fileId: hit.id, recipeId: (hit.appProperties && hit.appProperties.rbId) || '' };
    if (typeof o.keyOfRecord !== 'function') return null;
    return findLegacyDuplicate(rbKey, folderId, { interactive: inter, keyOfRecord: o.keyOfRecord });
  }

  function folderLink(id) { return 'https://drive.google.com/drive/folders/' + id; }

  const api = { DriveError: DriveError, getToken: getToken, ensureFolder: ensureFolder, ensureFolders: ensureFolders,
    saveDoc: saveDoc, saveJson: saveJson, findDuplicate: findDuplicate, folderLink: folderLink };
  globalThis.Drive = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
