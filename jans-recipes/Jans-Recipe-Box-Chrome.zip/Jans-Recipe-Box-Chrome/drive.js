'use strict';
// Google Drive helpers for the popup. Uses chrome.identity for sign-in; nothing runs in the background.
(function () {
  const API = 'https://www.googleapis.com/drive/v3';
  const UPLOAD = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink';
  const TOP_NAME = 'Recipe Box';
  const DATA_NAME = 'Recipe data';
  const FOLDER_MIME = 'application/vnd.google-apps.folder';

  class DriveError extends Error {
    constructor(message, status, reason) {
      super(message);
      this.name = 'DriveError';
      this.status = status || 0;
      this.reason = reason || '';
    }
  }

  async function getToken(interactive) {
    const r = await chrome.identity.getAuthToken({ interactive: !!interactive });
    const t = typeof r === 'string' ? r : r && r.token;
    if (!t) throw new DriveError('No sign-in', 0, 'NO_TOKEN');
    return t;
  }

  function send(url, init, token) {
    const headers = Object.assign({}, init && init.headers, { Authorization: 'Bearer ' + token });
    return fetch(url, Object.assign({}, init, { headers: headers }));
  }

  // On 401: drop the cached token and retry once interactively.
  async function authedFetch(url, init) {
    let token = await getToken(true);
    let res = await send(url, init, token);
    if (res.status === 401) {
      try { await chrome.identity.removeCachedAuthToken({ token: token }); } catch (_) { /* ignore */ }
      token = await getToken(true);
      res = await send(url, init, token);
    }
    return res;
  }

  async function ok(res) {
    if (res.ok) return res.json();
    let msg = 'HTTP ' + res.status, reason = '';
    try {
      const j = await res.json();
      if (j && j.error) {
        msg = j.error.message || msg;
        reason = (j.error.errors && j.error.errors[0] && j.error.errors[0].reason) || j.error.status || '';
      }
    } catch (_) { /* not json */ }
    throw new DriveError(msg, res.status, reason);
  }

  async function storeGet(key) {
    const o = await chrome.storage.local.get(key);
    return o ? o[key] : undefined;
  }
  async function storeSet(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }

  // Find or create a folder (optionally inside parentId). Cached id is confirmed to exist and not be trashed.
  async function ensureFolder(name, parentId, cacheKey) {
    const cached = await storeGet(cacheKey);
    if (cached) {
      const res = await authedFetch(API + '/files/' + encodeURIComponent(cached) + '?fields=id,trashed');
      if (res.ok) {
        const f = await res.json();
        if (f && f.id && !f.trashed) return f.id;
      } else if (res.status !== 404) {
        await ok(res); // throws
      }
    }
    let q = "name='" + name + "' and mimeType='" + FOLDER_MIME + "' and trashed=false";
    if (parentId) q += " and '" + parentId + "' in parents";
    const found = await ok(await authedFetch(API + '/files?q=' + encodeURIComponent(q) +
      '&fields=files(id,name)&orderBy=createdTime&pageSize=5&spaces=drive'));
    let id = found.files && found.files[0] && found.files[0].id;
    if (!id) {
      const body = { name: name, mimeType: FOLDER_MIME };
      if (parentId) body.parents = [parentId];
      const created = await ok(await authedFetch(API + '/files?fields=id', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(body)
      }));
      id = created.id;
    }
    await storeSet(cacheKey, id);
    return id;
  }

  // "Recipe Box" and "Recipe Box/Recipe data". The data folder is looked up inside the top folder.
  async function ensureFolders() {
    const folderId = await ensureFolder(TOP_NAME, null, 'folderId');
    const cachedParent = await storeGet('dataFolderParent');
    if (cachedParent && cachedParent !== folderId) await storeSet('dataFolderId', '');
    const dataFolderId = await ensureFolder(DATA_NAME, folderId, 'dataFolderId');
    await storeSet('dataFolderParent', folderId);
    return { folderId: folderId, dataFolderId: dataFolderId };
  }

  async function multipartUpload(metadata, content, contentType) {
    const b = 'recipebox' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    const body =
      '--' + b + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify(metadata) + '\r\n' +
      '--' + b + '\r\nContent-Type: ' + contentType + '\r\n\r\n' + content + '\r\n' +
      '--' + b + '--';
    return ok(await authedFetch(UPLOAD, {
      method: 'POST',
      headers: { 'Content-Type': 'multipart/related; boundary=' + b },
      body: body
    }));
  }

  // HTML -> Google Doc. Returns { id, webViewLink }.
  async function saveDoc(html, name, folderId) {
    const f = await multipartUpload(
      { name: name, mimeType: 'application/vnd.google-apps.document', parents: [folderId] },
      html, 'text/html; charset=UTF-8');
    if (!f.webViewLink) f.webViewLink = 'https://docs.google.com/document/d/' + f.id + '/edit';
    return f;
  }

  // Structured copy for the Mac app. Returns { id }.
  async function saveJson(jsonText, fileName, dataFolderId) {
    return multipartUpload(
      { name: fileName, mimeType: 'application/json', parents: [dataFolderId] },
      jsonText, 'application/json; charset=UTF-8');
  }

  function folderLink(id) { return 'https://drive.google.com/drive/folders/' + id; }

  const api = { DriveError: DriveError, getToken: getToken, ensureFolder: ensureFolder, ensureFolders: ensureFolders,
    saveDoc: saveDoc, saveJson: saveJson, folderLink: folderLink };
  globalThis.Drive = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
