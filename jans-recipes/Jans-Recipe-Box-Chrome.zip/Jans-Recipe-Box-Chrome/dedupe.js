'use strict';
// Duplicate key for a recipe, shared in spirit and in test vectors (docs/dedupe-vectors.json) with the app
// (mac/RecipeBox/SharedCore/Services/DuplicateKey.swift). Keep the two in step: the vectors are the contract.
//
//   key   = "url:" + normalizedUrl                              (record has an http(s) source URL)
//         | "txt:" + normalizedTitle + "|" + lines.join(";")    (no URL; lines = normalized, non-empty ingredient lines)
//         | null                                                (no URL and no ingredient lines: nothing to compare)
//   rbKey = lowercase hex SHA-256 of the UTF-8 bytes of key     (what is stored as Drive appProperties.rbKey)
(function () {
  const ID_RE = /^[A-Za-z0-9_-]+$/;

  // Lowercase, letters and digits only (any script), one space between words, no punctuation.
  function normalizeText(s) {
    return String(s == null ? '' : s).normalize('NFC').toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, '')
      .replace(/\s+/gu, ' ')
      .trim();
  }

  // https://host[:port]/path  - no query, fragment, userinfo, www./m., trailing slash. null when not an http(s) address.
  // YouTube watch, youtu.be and shorts addresses all become https://youtube.com/watch?v=<id>.
  function normalizeUrl(input) {
    const s = String(input == null ? '' : input).trim();
    const m = /^(https?):\/\/([^\/?#]*)([^?#]*)(?:\?([^#]*))?(?:#.*)?$/i.exec(s);
    if (!m) return null;
    const scheme = m[1].toLowerCase();
    let auth = m[2];
    const at = auth.lastIndexOf('@');
    if (at >= 0) auth = auth.slice(at + 1);
    let host = auth;
    let port = '';
    const pm = /^(.*):(\d+)$/.exec(auth);
    if (pm) { host = pm[1]; port = pm[2]; }
    host = host.toLowerCase();
    if (!host) return null;
    if (host.startsWith('www.') && host.slice(4).indexOf('.') >= 0) host = host.slice(4);
    if (host.startsWith('m.') && host.slice(2).indexOf('.') >= 0) host = host.slice(2);
    if ((scheme === 'http' && port === '80') || (scheme === 'https' && port === '443')) port = '';
    const path = m[3].replace(/%[0-9a-f]{2}/gi, function (x) { return x.toUpperCase(); }).replace(/\/+$/, '');
    const query = m[4] || '';

    let id = '';
    if (host === 'youtu.be') {
      const seg = /^\/([^\/]+)/.exec(path);
      id = seg ? seg[1] : '';
    } else if (host === 'youtube.com') {
      const sh = /^\/shorts\/([^\/]+)/.exec(path);
      if (sh) id = sh[1];
      else if (path === '/watch') {
        const parts = query.split('&');
        for (let i = 0; i < parts.length; i++) {
          if (parts[i].indexOf('v=') === 0) { id = parts[i].slice(2); break; }
        }
      }
    }
    if (id && ID_RE.test(id)) return 'https://youtube.com/watch?v=' + id;

    return 'https://' + host + (port ? ':' + port : '') + path;
  }

  // rec: { url, name, ingredients[] }
  function recipeKey(rec) {
    const r = rec || {};
    const u = normalizeUrl(r.url);
    if (u) return 'url:' + u;
    const lines = (Array.isArray(r.ingredients) ? r.ingredients : []).map(normalizeText).filter(Boolean);
    if (!lines.length) return null;
    return 'txt:' + normalizeText(r.name) + '|' + lines.join(';');
  }

  async function rbKeyFromKey(key) {
    const bytes = new TextEncoder().encode(String(key));
    const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
  }

  // Drive appProperties.rbKey for a record, or null when it has no key.
  async function rbKeyOfRecord(rec) {
    const k = recipeKey(rec);
    return k ? rbKeyFromKey(k) : null;
  }

  const api = { normalizeText: normalizeText, normalizeUrl: normalizeUrl, recipeKey: recipeKey, rbKeyFromKey: rbKeyFromKey, rbKeyOfRecord: rbKeyOfRecord };
  globalThis.Dedupe = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
