'use strict';
// YouTube support. Classic script (popup) and CommonJS module (tests): exposes globalThis.RecipeYouTube.
// Pure helpers plus recipeBoxExtractYouTube, the function that runs INSIDE the YouTube tab
// (chrome.scripting.executeScript). That function must stay fully self-contained.
(function () {
  var YT_HOSTS = /^(www\.|m\.|music\.)?youtube(-nocookie)?\.com$/i;
  var ID_RE = /^[A-Za-z0-9_-]{11}$/;

  function parseUrl(url) {
    try { return new URL(String(url)); } catch (_) { return null; }
  }

  // True for any youtube.com / m.youtube.com / youtu.be address. Use videoIdFrom to know if it is a video.
  function isYouTubeUrl(url) {
    var u = parseUrl(url);
    if (!u || !/^https?:$/.test(u.protocol)) return false;
    return YT_HOSTS.test(u.hostname) || /^(www\.)?youtu\.be$/i.test(u.hostname);
  }

  // Video id from watch, shorts, live, embed, v/ and youtu.be forms; '' when there is none.
  function videoIdFrom(url) {
    var u = parseUrl(url);
    if (!u || !isYouTubeUrl(url)) return '';
    var id = '';
    if (/^(www\.)?youtu\.be$/i.test(u.hostname)) {
      id = u.pathname.split('/')[1] || '';
    } else {
      var m = u.pathname.match(/^\/(?:shorts|live|embed|v)\/([^/?#]+)/);
      if (m) id = m[1];
      else if (u.pathname === '/watch') id = u.searchParams.get('v') || '';
    }
    return ID_RE.test(id) ? id : '';
  }

  function canonicalUrl(id) { return 'https://www.youtube.com/watch?v=' + id; }

  // ---- recipe links in a description ----
  var SOCIAL = /(^|\.)(instagram\.com|facebook\.com|fb\.com|fb\.me|tiktok\.com|twitter\.com|x\.com|t\.co|pinterest\.[a-z.]+|pin\.it|threads\.net|threads\.com|snapchat\.com|linkedin\.com|discord\.gg|discord\.com|twitch\.tv|reddit\.com|spotify\.com|paypal\.me|paypal\.com|ko-fi\.com|buymeacoffee\.com)$/i;
  var SHOPS = /(^|\.)(amazon\.[a-z.]+|amzn\.to|amzn\.com|a\.co|patreon\.com|shopify\.com|myshopify\.com|shopmy\.us|rstyle\.me|liketk\.it|ltk\.app|teespring\.com|etsy\.com|ebay\.com|walmart\.com|target\.com|kit\.co)$/i;
  var SHOP_WORDS = /(shop|store|merch)/i;
  var YOUTUBE = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|youtubekids\.com)$/i;
  var HINT = /recipe|ingredients|full|printable|written|get the/i;

  function extractRecipeLinks(description) {
    var text = String(description || '');
    var lines = text.split(/\r?\n/);
    var found = [];
    var seen = {};
    for (var i = 0; i < lines.length; i++) {
      var re = /https?:\/\/[^\s<>"'\])]+/gi;
      var m;
      while ((m = re.exec(lines[i]))) {
        var raw = m[0].replace(/[.,;:!?)\]]+$/, '');
        var u = parseUrl(raw);
        if (!u) continue;
        var host = u.hostname.toLowerCase();
        if (YOUTUBE.test(host) || SOCIAL.test(host) || SHOPS.test(host) || SHOP_WORDS.test(host)) continue;
        var key = u.hostname.replace(/^www\./, '') + u.pathname.replace(/\/$/, '') + u.search;
        if (seen[key]) continue;
        seen[key] = true;
        // Creators often put "Full recipe:" on the line above the link.
        var context = (i > 0 ? lines[i - 1] + ' ' : '') + lines[i].replace(m[0], ' ');
        found.push({ url: raw, rank: HINT.test(context) ? 0 : 1, order: found.length });
      }
    }
    found.sort(function (a, b) { return a.rank - b.rank || a.order - b.order; });
    return found.slice(0, 5).map(function (f) { return f.url; });
  }

  // Lines that start with a quantity ("2 cups flour", "1/2 tsp salt", "200g butter").
  var UNIT = '(?:g|kg|mg|ml|l|oz|lb|lbs|cups?|tbsp|tsp|tablespoons?|teaspoons?|cloves?|pinch|dash|cans?|sticks?|slices?|pieces?|large|medium|small|bunch|handful)';
  var QTY_LINE = new RegExp('^\\s*(?:[-*\\u2022]\\s*)?(?:\\d+\\s+\\d+/\\d+|\\d+[/.]\\d+|\\d+|[\\u00BC-\\u00BE\\u2150-\\u215E])(?!\\s*[:.)]\\s)(?:\\s*' + UNIT + '\\b|\\s+[A-Za-z])', 'i');
  function countIngredientLines(description) {
    var n = 0;
    String(description || '').split(/\r?\n/).forEach(function (line) {
      if (/^\s*\d{1,2}:\d{2}/.test(line)) return;       // chapter timestamps
      if (QTY_LINE.test(line)) n++;
    });
    return n;
  }

  // What the popup tells her was found. info: { recipeLinks, description, transcript }
  function findingFor(info) {
    var links = (info && info.recipeLinks) || [];
    if (links.length) return { code: 'link', message: 'Found a link to the written recipe' };
    if (countIngredientLines(info && info.description) >= 3) return { code: 'description', message: 'The recipe is in the video description' };
    var t = info && info.transcript;
    if (t && t.text) return { code: 'captions', message: "I will read the video's captions to write the recipe" };
    return { code: 'none', message: 'No captions found. I will save the video so you can watch it again.' };
  }

  // ---- ytInitialPlayerResponse out of a watch page's HTML ----
  function parseYtInitialPlayerResponse(html) {
    var s = String(html || '');
    var re = /ytInitialPlayerResponse\s*=\s*\{/g;
    var m;
    while ((m = re.exec(s))) {
      var start = m.index + m[0].length - 1;
      var depth = 0, inStr = false, esc = false;
      for (var i = start; i < s.length; i++) {
        var c = s[i];
        if (inStr) {
          if (esc) esc = false;
          else if (c === '\\') esc = true;
          else if (c === '"') inStr = false;
        } else if (c === '"') inStr = true;
        else if (c === '{') depth++;
        else if (c === '}') {
          depth--;
          if (depth === 0) {
            try { return JSON.parse(s.slice(start, i + 1)); } catch (_) { break; }
          }
        }
      }
    }
    return null;
  }

  // ---- runs in the YouTube tab; self-contained on purpose ----
  async function recipeBoxExtractYouTube() {
    var out = {
      isYouTube: false, videoId: '', title: '', channel: '', description: '', thumbnail: '', durationSeconds: 0,
      url: '', transcript: { lang: '', kind: '', text: '', segments: [] }, error: ''
    };
    var CAP = 60000;
    try {
      var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
      var host = location.hostname;
      out.isYouTube = /(^|\.)youtube\.com$/i.test(host);
      if (!out.isYouTube) { out.error = 'Not a YouTube page'; return out; }

      var idFromHref = function (href) {
        try {
          var u = new URL(href, location.origin);
          var m = u.pathname.match(/^\/(?:shorts|live|embed|v)\/([^/?#]+)/);
          var id = m ? m[1] : (u.pathname === '/watch' ? u.searchParams.get('v') || '' : '');
          return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : '';
        } catch (_) { return ''; }
      };
      var wantId = idFromHref(location.href);
      if (!wantId) { out.error = 'This page is not a YouTube video'; return out; }

      var parsePR = function (html) {
        var re = /ytInitialPlayerResponse\s*=\s*\{/g, m;
        while ((m = re.exec(html))) {
          var start = m.index + m[0].length - 1, depth = 0, inStr = false, esc = false;
          for (var i = start; i < html.length; i++) {
            var c = html[i];
            if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; }
            else if (c === '"') inStr = true;
            else if (c === '{') depth++;
            else if (c === '}') {
              depth--;
              if (depth === 0) { try { return JSON.parse(html.slice(start, i + 1)); } catch (_) { break; } }
            }
          }
        }
        return null;
      };
      var matches = function (pr) { return !!(pr && pr.videoDetails && pr.videoDetails.videoId === wantId); };

      // 1. Fresh HTML of the current URL (YouTube is a single-page app, so in-page globals can be stale).
      var pr = null;
      try {
        var res = await fetch(location.href, { credentials: 'same-origin' });
        if (res.ok) { pr = parsePR(await res.text()); }
      } catch (_) { /* fall through */ }
      if (!matches(pr)) {
        try {
          var res2 = await fetch(location.origin + '/watch?v=' + wantId, { credentials: 'same-origin' });
          if (res2.ok) pr = parsePR(await res2.text());
        } catch (_) { /* fall through */ }
      }
      // 2. Page globals, only when they are for this video.
      if (!matches(pr)) {
        var cand = [];
        try { cand.push(window.ytInitialPlayerResponse); } catch (_) {}
        try { var pl = document.getElementById('movie_player'); if (pl && pl.getPlayerResponse) cand.push(pl.getPlayerResponse()); } catch (_) {}
        pr = null;
        for (var ci = 0; ci < cand.length; ci++) { if (matches(cand[ci])) { pr = cand[ci]; break; } }
      }
      if (!pr) { out.error = "I couldn't read this video's details. Please reload the page and try again."; return out; }

      var vd = pr.videoDetails;
      out.videoId = vd.videoId;
      out.title = String(vd.title || '');
      out.channel = String(vd.author || '');
      out.description = String(vd.shortDescription || '');
      out.durationSeconds = parseInt(vd.lengthSeconds, 10) || 0;
      out.url = 'https://www.youtube.com/watch?v=' + vd.videoId;
      var thumbs = (vd.thumbnail && vd.thumbnail.thumbnails) || [];
      var hasMax = thumbs.some(function (t) { return t && /maxresdefault/.test(t.url || ''); });
      out.thumbnail = 'https://i.ytimg.com/vi/' + vd.videoId + '/' + (hasMax ? 'maxresdefault' : 'hqdefault') + '.jpg';

      // ---- transcript ----
      var tracks = [];
      try { tracks = pr.captions.playerCaptionsTracklistRenderer.captionTracks || []; } catch (_) { tracks = []; }
      var isEn = function (t) { return /^en/i.test(t.languageCode || ''); };
      var track = tracks.filter(function (t) { return isEn(t) && t.kind !== 'asr'; })[0]
        || tracks.filter(function (t) { return isEn(t) && t.kind === 'asr'; })[0]
        || tracks[0] || null;
      var tLang = track ? String(track.languageCode || '') : '';
      var tKind = track ? (track.kind === 'asr' ? 'auto' : 'manual') : '';

      var finish = function (segs, lang, kind) {
        var total = 0, kept = [], parts = [];
        for (var i = 0; i < segs.length; i++) {
          var tx = segs[i].text;
          if (!tx) continue;
          if (total + tx.length + 1 > CAP) { tx = tx.slice(0, Math.max(0, CAP - total)); if (!tx) break; }
          kept.push({ start: segs[i].start, text: tx });
          parts.push(tx);
          total += tx.length + 1;
          if (total >= CAP) break;
        }
        out.transcript = { lang: lang, kind: kind, text: parts.join(' ').slice(0, CAP), segments: kept };
      };

      if (track && track.baseUrl) {
        try {
          var tu = new URL(track.baseUrl, location.origin);
          if (/(^|\.)youtube\.com$/i.test(tu.hostname)) tu.host = location.host;
          tu.searchParams.set('fmt', 'json3');
          var tr = await fetch(tu.toString(), { credentials: 'same-origin' });
          if (tr.ok) {
            var body = await tr.text();
            if (body) {
              var j = JSON.parse(body);
              var segs = [];
              (j.events || []).forEach(function (ev) {
                if (!ev.segs) return;
                var tx = ev.segs.map(function (s) { return s.utf8 || ''; }).join('').replace(/\s+/g, ' ').trim();
                if (tx) segs.push({ start: Math.round((ev.tStartMs || 0) / 100) / 10, text: tx });
              });
              if (segs.length) finish(segs, tLang, tKind);
            }
          }
        } catch (_) { /* use the page fallback */ }
      }

      // Fallback: open the transcript panel in the page and read it.
      if (!out.transcript.text && tracks.length) {
        try {
          var q = function (s) { return document.querySelector(s); };
          var segSel = 'ytd-transcript-segment-renderer';
          var opened = false;
          if (!q(segSel)) {
            var btnSel = 'ytd-video-description-transcript-section-renderer button, button[aria-label="Show transcript"]';
            var findBtn = function () {
              var b = q(btnSel);
              if (b) return b;
              var all = document.querySelectorAll('button, yt-button-shape button');
              for (var i = 0; i < all.length; i++) {
                if (/^\s*show transcript\s*$/i.test(all[i].textContent || '')) return all[i];
              }
              return null;
            };
            var btn = findBtn();
            if (!btn) {
              var exp = q('#description-inline-expander #expand, ytd-text-inline-expander #expand, tp-yt-paper-button#expand');
              if (exp) { exp.click(); await sleep(500); }
              btn = findBtn();
            }
            if (btn) { btn.click(); opened = true; }
          }
          var waited = 0;
          while (!q(segSel) && waited < 4000) { await sleep(200); waited += 200; }
          var els = document.querySelectorAll(segSel);
          var toSec = function (s) {
            var p = String(s || '').trim().split(':').map(function (x) { return parseInt(x, 10); });
            if (!p.length || p.some(isNaN)) return 0;
            return p.reduce(function (a, b) { return a * 60 + b; }, 0);
          };
          var dsegs = [];
          for (var k = 0; k < els.length; k++) {
            var tsEl = els[k].querySelector('.segment-timestamp');
            var txEl = els[k].querySelector('.segment-text') || els[k].querySelector('yt-formatted-string');
            var tx2 = ((txEl && txEl.textContent) || '').replace(/\s+/g, ' ').trim();
            if (tx2) dsegs.push({ start: toSec(tsEl && tsEl.textContent), text: tx2 });
          }
          if (dsegs.length) finish(dsegs, tLang, tKind);
          if (opened) {
            var panel = q('ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"]');
            var close = panel && panel.querySelector('#visibility-button button, button[aria-label="Close"]');
            if (close) close.click();
          }
        } catch (_) { /* no transcript */ }
      }
      return out;
    } catch (e) {
      out.error = String((e && e.message) || e);
      return out;
    }
  }

  var api = {
    isYouTubeUrl: isYouTubeUrl,
    videoIdFrom: videoIdFrom,
    canonicalUrl: canonicalUrl,
    extractRecipeLinks: extractRecipeLinks,
    countIngredientLines: countIngredientLines,
    findingFor: findingFor,
    parseYtInitialPlayerResponse: parseYtInitialPlayerResponse,
    recipeBoxExtractYouTube: recipeBoxExtractYouTube
  };
  globalThis.RecipeYouTube = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
